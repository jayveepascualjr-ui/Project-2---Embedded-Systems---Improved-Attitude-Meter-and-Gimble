#include <eeng1030_lib.h>
#include <stdio.h>
#include <errno.h>
#include <math.h>   
#include <sys/unistd.h>
#include "i2c.h"
#include "display.h"

// -------------------------------------------------------
// TUNING CONSTANTS
// -------------------------------------------------------
#define DEADZONE        1500
#define STEP_SIZE       3.0f
#define SMOOTH_ALPHA    0.3f
#define ANGLE_LOW       30
#define ANGLE_HIGH      150

volatile int is_paused = 0;

// --- PROFESSOR'S SINE WAVE TABLE ---
#define NUM_SAMPLES 180
static const int16_t samples[NUM_SAMPLES * 2] = {
    0,0,142,142,285,285,428,428,570,570,711,711,851,851,990,990,1128,1128,1265,1265,1400,1400,1534,1534,1665,1665,1795,1795,1922,1922,2047,2047,2170,2170,2290,2290,2407,2407,2521,2521,2632,2632,2740,2740,2845,2845,2946,2946,3043,3043,3137,3137,3227,3227,3313,3313,3395,3395,3473,3473,3547,3547,3616,3616,3681,3681,3741,3741,3797,3797,3848,3848,3895,3895,3937,3937,3974,3974,4006,4006,4033,4033,4056,4056,4073,4073,4085,4085,4093,4093,4095,4095,4093,4093,4085,4085,4073,4073,4056,4056,4033,4033,4006,4006,3974,3974,3937,3937,3895,3895,3848,3848,3797,3797,3741,3741,3681,3681,3616,3616,3547,3547,3473,3473,3395,3395,3313,3313,3227,3227,3137,3137,3043,3043,2946,2946,2845,2845,2740,2740,2632,2632,2521,2521,2407,2407,2290,2290,2170,2170,2047,2047,1922,1922,1795,1795,1665,1665,1534,1534,1400,1400,1265,1265,1128,1128,990,990,851,851,711,711,570,570,428,428,285,285,142,142,0,0,-142,-142,-285,-285,-428,-428,-570,-570,-711,-711,-851,-851,-990,-990,-1128,-1128,-1265,-1265,-1400,-1400,-1534,-1534,-1665,-1665,-1795,-1795,-1922,-1922,-2047,-2047,-2170,-2170,-2290,-2290,-2407,-2407,-2521,-2521,-2632,-2632,-2740,-2740,-2845,-2845,-2946,-2946,-3043,-3043,-3137,-3137,-3227,-3227,-3313,-3313,-3395,-3395,-3473,-3473,-3547,-3547,-3616,-3616,-3681,-3681,-3741,-3741,-3797,-3797,-3848,-3848,-3895,-3895,-3937,-3937,-3974,-3974,-4006,-4006,-4033,-4033,-4056,-4056,-4073,-4073,-4085,-4085,-4093,-4093,-4095,-4095,-4093,-4093,-4085,-4085,-4073,-4073,-4056,-4056,-4033,-4033,-4006,-4006,-3974,-3974,-3937,-3937,-3895,-3895,-3848,-3848,-3797,-3797,-3741,-3741,-3681,-3681,-3616,-3616,-3547,-3547,-3473,-3473,-3395,-3395,-3313,-3313,-3227,-3227,-3137,-3137,-3043,-3043,-2946,-2946,-2845,-2845,-2740,-2740,-2632,-2632,-2521,-2521,-2407,-2407,-2290,-2290,-2170,-2170,-2047,-2047,-1922,-1922,-1795,-1795,-1665,-1665,-1534,-1534,-1400,-1400,-1265,-1265,-1128,-1128,-990,-990,-851,-851,-711,-711,-570,-570,-428,-428,-285,-285,-142,-142
};

// --- Prototypes ---
void setup(void);
void initSerial(uint32_t baudrate);
void eputc(char c);
void delay_ms(volatile uint32_t dly);
void setup_hardware_pwm(void);
void setup_button_interrupt(void);
void setup_sai_audio(void);  
void delay(volatile uint32_t dly) { while(dly--); }

// Interrupt for Pause Button
void EXTI0_IRQHandler(void) {
    if (EXTI->PR1 & (1 << 0)) {
        is_paused = !is_paused;
        EXTI->PR1 |= (1 << 0);
    }
}

// LCD Printing Helper
void lcd_update_telemetry(int row, const char *label, int deg) {
    char buf[32];
    fillRectangle(0, row, 159, row + 9, RGBToWord(0, 0, 0));
    sprintf(buf, "%s: %3d deg", label, deg);
    printText(buf, 2, row, RGBToWord(255, 255, 255), RGBToWord(0, 0, 0));
}

int main() {
    setup();
    setup_hardware_pwm();
    setup_button_interrupt();
    setup_sai_audio();      

    init_display();
    fillRectangle(0, 0, 159, 79, RGBToWord(0, 0, 0));

    ResetI2C();
    I2CStart(0x69, WRITE, 2);
    I2CWrite(0x7E); I2CWrite(0x11);
    I2CStop();
    delay_ms(200);

    float s_pos_roll = 1500.0f;
    float s_pos_pitch = 1500.0f;
    float smooth_r = 0.0f, smooth_p = 0.0f;
    int last_roll = -999, last_pitch = -999;
    int alarm_active = 0;

    printf("\n--- Telemetry Online ---\n");

    while (1) {
        // --- Read Accelerometer ---
        I2CStart(0x69, WRITE, 1); I2CWrite(0x12);
        I2CReStart(0x69, READ, 2);
        int16_t roll_raw = (int16_t)(I2CRead() | (I2CRead() << 8));
        I2CStop();

        I2CStart(0x69, WRITE, 1); I2CWrite(0x14);
        I2CReStart(0x69, READ, 2);
        int16_t pitch_raw = (int16_t)(I2CRead() | (I2CRead() << 8));
        I2CStop();

        smooth_r = (SMOOTH_ALPHA * (float)roll_raw) + (1.0f - SMOOTH_ALPHA) * smooth_r;
        smooth_p = (SMOOTH_ALPHA * (float)pitch_raw) + (1.0f - SMOOTH_ALPHA) * smooth_p;

        if (!is_paused) {
            // 1. Update Servo Signals
            if (smooth_r > DEADZONE) s_pos_roll += STEP_SIZE;
            else if (smooth_r < -DEADZONE) s_pos_roll -= STEP_SIZE;
            if (smooth_p > DEADZONE) s_pos_pitch += STEP_SIZE;
            else if (smooth_p < -DEADZONE) s_pos_pitch -= STEP_SIZE;

            if (s_pos_roll > 2500.0f) s_pos_roll = 2500.0f;
            if (s_pos_roll < 500.0f)  s_pos_roll = 500.0f;
            if (s_pos_pitch > 2500.0f) s_pos_pitch = 2500.0f;
            if (s_pos_pitch < 500.0f)  s_pos_pitch = 500.0f;

            TIM2->CCR1 = (int)s_pos_roll;
            TIM2->CCR4 = (int)s_pos_pitch;

            // 2. LED Brightness
            float diff = fmaxf(fabsf(s_pos_roll - 1500.0f), fabsf(s_pos_pitch - 1500.0f));
            TIM1->CCR3 = (int)diff;

            // 3. Convert to Degrees
            int deg_r = (int)((s_pos_roll - 500.0f) * 180.0f / 2000.0f);
            int deg_p = (int)((s_pos_pitch - 500.0f) * 180.0f / 2000.0f);

            // 4. Update Alarm
            int hazard = (deg_r < ANGLE_LOW || deg_r > ANGLE_HIGH || deg_p < ANGLE_LOW || deg_p > ANGLE_HIGH);
            if (hazard && !alarm_active) {
                SAI1_Block_A->CR1 |= (1u << 16); alarm_active = 1;
            } else if (!hazard && alarm_active) {
                SAI1_Block_A->CR1 &= ~(1u << 16); alarm_active = 0;
            }

            // 5. Update LCD & SERIAL
            if (deg_r != last_roll || deg_p != last_pitch) {
                lcd_update_telemetry(10, "Roll ", deg_r);
                lcd_update_telemetry(25, "Pitch", deg_p);
                printf("Roll: %3d | Pitch: %3d\n", deg_r, deg_p); // Prints to PlatformIO monitor
                last_roll = deg_r;
                last_pitch = deg_p;
            }

        } else {
            TIM1->CCR3 = 0;
            if (alarm_active) { SAI1_Block_A->CR1 &= ~(1u << 16); alarm_active = 0; }
        }
        delay_ms(10);
    }
}

void setup_sai_audio(void) {
    GPIOA->MODER &= ~((3u << 16) | (3u << 18) | (3u << 20));
    GPIOA->MODER |=  ((2u << 16) | (2u << 18) | (2u << 20));
    GPIOA->AFR[1] &= ~((0xFu << 0) | (0xFu << 4) | (0xFu << 8));
    GPIOA->AFR[1] |=  ((13u << 0) | (13u << 4) | (13u << 8));
    RCC->APB2ENR |= (1u << 21);
    RCC->PLLSAI1CFGR = (2u << 27) | (37u << 8) | (1u << 16);
    RCC->CR |= (1u << 26);
    while (!(RCC->CR & (1u << 27)));  
    SAI1_Block_A->CR2  = 0;
    SAI1_Block_A->CR1  = (7u << 5) | (3u << 20) | (1u << 9);
    SAI1_Block_A->SLOTR |= (1u << 8) | (1u << 16) | (1u << 17) | (1u << 7);
    SAI1_Block_A->FRCR   = (1u << 18) | (1u << 16) | (15u << 8) | (32u - 1);
    SAI1_Block_A->CR1   |= (1u << 17);   
    SAI1->GCR = (1u << 4);
    RCC->AHB1ENR |= (1u << 1);           
    DMA2_Channel6->CMAR  = (uint32_t)samples;
    DMA2_Channel6->CPAR  = (uint32_t)&SAI1_Block_A->DR;
    DMA2_Channel6->CNDTR = NUM_SAMPLES * 2; 
    DMA2_CSELR->CSELR   |= (1u << 20);   
    DMA2_Channel6->CCR   = (1u << 11) | (1u << 8) | (1u << 7) | (1u << 5) | (1u << 4) | (1u << 0);
    SAI1_Block_A->CR1 &= ~(1u << 16); // Start disabled
}

void setup_hardware_pwm(void) {
    RCC->APB1ENR1 |= (1u << 0);
    pinMode(GPIOA, 0, 2); selectAlternateFunction(GPIOA, 0, 1);
    pinMode(GPIOA, 3, 2); selectAlternateFunction(GPIOA, 3, 1);
    TIM2->PSC = 80 - 1; TIM2->ARR = 20000 - 1;
    TIM2->CCMR1 |= (6u << 4); TIM2->CCER |= (1u << 0);   
    TIM2->CCMR2 |= (6u << 12); TIM2->CCER |= (1u << 12);  
    TIM2->CR1 |= (1u << 0);
    RCC->APB2ENR |= (1u << 11);
    pinMode(GPIOB, 1, 2); selectAlternateFunction(GPIOB, 1, 1);
    TIM1->PSC = 80 - 1; TIM1->ARR = 1000 - 1;
    TIM1->CCMR2 |= (6u << 4); TIM1->CCER |= (1u << 10);  
    TIM1->BDTR |= (1u << 15); TIM1->CR1 |= (1u << 0);
}

void setup_button_interrupt(void) {
    pinMode(GPIOB, 0, 0); GPIOB->PUPDR |= (1u << 0);          
    RCC->APB2ENR |= (1u << 0);          
    SYSCFG->EXTICR[0] |= 0x1u;          
    EXTI->IMR1 |= (1u << 0); EXTI->FTSR1 |= (1u << 0);           
    NVIC_EnableIRQ(EXTI0_IRQn);
}

void setup(void) {
    initClocks();
    SysTick->LOAD = 80000 - 1; SysTick->CTRL = 7; SysTick->VAL = 10;
    RCC->AHB2ENR |= (1u << 0) | (1u << 1);  
    initSerial(9600);
    initI2C();
    __asm(" cpsie i ");
}

void initSerial(uint32_t baudrate) {
    pinMode(GPIOA, 2, 2); selectAlternateFunction(GPIOA, 2, 7);
    RCC->APB1ENR1 |= (1u << 17);
    USART2->BRR = 80000000 / baudrate;
    USART2->CR1 = (1u << 3) | (1u << 0);
}

void eputc(char c) {
    while ((USART2->ISR & (1u << 6)) == 0);
    USART2->TDR = c;
}

int _write(int file, char *data, int len) {
    for (int i = 0; i < len; i++) eputc(data[i]);
    return len;
}